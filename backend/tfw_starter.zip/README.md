# test-tutorial-framework

This is an example playground project built via TFW. It is a good starting point to build your own challenges from. It also gives home to several useful scripts in the hack folder to speed up development. If you are unfamiliar with the *Avatao* challenge structure, inspect the [challenge-toolbox](https://github.com/avatao-content/challenge-toolbox) first.

To learn more about the framework and get started, please consult our [wiki](https://github.com/avatao-content/baseimage-tutorial-framework/wiki).
