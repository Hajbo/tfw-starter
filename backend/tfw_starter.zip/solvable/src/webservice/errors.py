class InvalidCredentialsError(RuntimeError):
    pass


class UserExistsError(RuntimeError):
    pass
